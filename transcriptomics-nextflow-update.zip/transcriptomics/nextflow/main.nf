#!/usr/bin/env nextflow
/*
 * WNV host transcriptomics pipeline
 *
 * Reflects the RNA-seq workflow used in my thesis for WNV-infected vs.
 * mock-treated (and IFNb / MDA5 / RIG-I stimulated) human samples:
 * GEO GSE136342 / BioProject PRJNA562253.
 *
 *   raw FASTQ --FastQC/MultiQC--> STAR (GRCh38) --featureCounts--> counts
 *      --> DESeq2 (design = ~ donor + treatment + timepoint, apeglm
 *          shrinkage, Mock as reference) --> per-contrast DE tables
 *      --> GSVA interferon-stimulated-gene scoring
 *      --> GO/KEGG enrichment (clusterProfiler)
 *
 * Two entry points:
 *
 *   1. Full pipeline, from raw FASTQ (needs a STAR index + GTF + real
 *      FASTQ files -- not runnable offline/without a reference genome):
 *
 *        nextflow run main.nf \
 *            --reads 'data/*_R{1,2}.fastq.gz' \
 *            --star_index /path/to/GRCh38_STAR_index \
 *            --gtf /path/to/gencode.v42.annotation.gtf \
 *            --outdir results
 *
 *   2. Downstream-only, starting from a count matrix (this is what the
 *      included test profile exercises, since it needs no genome/FASTQ):
 *
 *        nextflow run main.nf -profile test
 *
 *      or, with your own count matrix + metadata:
 *
 *        nextflow run main.nf --skip_alignment \
 *            --counts my_counts.csv --metadata my_metadata.csv \
 *            --outdir results
 */

nextflow.enable.dsl = 2

include { FASTQC }           from './modules/fastqc.nf'
include { MULTIQC }          from './modules/multiqc.nf'
include { STAR_ALIGN }       from './modules/star_align.nf'
include { FEATURECOUNTS }    from './modules/featurecounts.nf'
include { DESEQ2_ANALYSIS }  from './modules/deseq2.nf'

params.reads            = null
params.star_index       = null
params.gtf              = null
params.counts           = null
params.metadata         = null
params.skip_alignment   = false
params.isg_genes        = null
params.skip_enrichment  = false
params.outdir           = 'results'

workflow {

    if (!params.skip_alignment) {
        if (!params.reads || !params.star_index || !params.gtf) {
            error "Full-pipeline mode requires --reads, --star_index, and --gtf " +
                  "(or pass --skip_alignment with --counts/--metadata to run the " +
                  "downstream-only stage -- see the header of main.nf)"
        }

        read_pairs_ch = Channel.fromFilePairs(params.reads, checkIfExists: true)

        FASTQC(read_pairs_ch)
        MULTIQC(FASTQC.out.reports.collect())

        STAR_ALIGN(read_pairs_ch, params.star_index)
        FEATURECOUNTS(STAR_ALIGN.out.bam.map { it[1] }.collect(), params.gtf)

        DESEQ2_ANALYSIS(FEATURECOUNTS.out.count_matrix, params.metadata)

    } else {
        if (!params.counts || !params.metadata) {
            error "--skip_alignment requires --counts and --metadata"
        }
        DESEQ2_ANALYSIS(file(params.counts), file(params.metadata))
    }
}
