process FEATURECOUNTS {
    container 'quay.io/biocontainers/subread:2.0.6--he4a0461_2'
    publishDir "${params.outdir}/counts", mode: 'copy'
    cpus 8

    input:
        path(bam_files)
        path gtf

    output:
        path("count.txt"), emit: raw_counts
        path("count.csv"), emit: count_matrix

    script:
    // gene-level quantification, then a safe delimiter conversion
    // (plain sed, not a loose tab->comma regex that could touch gene IDs)
    """
    featureCounts -T ${task.cpus} -p -a ${gtf} -o count.txt ${bam_files}
    grep -v '^#' count.txt | cut -f1,7- > count_body.txt
    sed 's/\\t/,/g' count_body.txt > count.csv
    """
}
