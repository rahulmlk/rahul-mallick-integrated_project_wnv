process MULTIQC {
    container 'multiqc/multiqc:v1.21'
    publishDir "${params.outdir}/qc/multiqc", mode: 'copy'

    input:
        path('fastqc/*')

    output:
        path("multiqc_report.html")
        path("multiqc_data")

    script:
    """
    multiqc fastqc/ --filename multiqc_report.html
    """
}
