process DESEQ2_ANALYSIS {
    container 'bioconductor/bioconductor_docker:RELEASE_3_18'
    publishDir "${params.outdir}/deseq2", mode: 'copy'

    input:
        path counts_csv
        path metadata_csv

    output:
        path("tables/*.csv")
        path("figures/*.png")

    script:
    def isg_flag = params.isg_genes ? "--isg-genes ${params.isg_genes}" : ""
    def skip_flag = params.skip_enrichment ? "--skip-enrichment" : ""
    """
    Rscript ${projectDir}/bin/deseq2_analysis.R ${counts_csv} ${metadata_csv} . ${isg_flag} ${skip_flag}
    """
}
