process STAR_ALIGN {
    tag "$sample_id"
    container 'quay.io/biocontainers/star:2.7.11a--h0033a41_0'
    publishDir "${params.outdir}/align", mode: 'copy', pattern: "*.bam"
    cpus 8

    input:
        tuple val(sample_id), path(reads)
        path star_index

    output:
        tuple val(sample_id), path("${sample_id}_Aligned.sortedByCoord.out.bam"), emit: bam
        path("${sample_id}_Log.final.out"), emit: log

    script:
    // splice-aware alignment to GRCh38, matching the thesis pipeline
    """
    STAR --runThreadN ${task.cpus} \\
         --genomeDir ${star_index} \\
         --readFilesIn ${reads} \\
         --readFilesCommand zcat \\
         --outSAMtype BAM SortedByCoordinate \\
         --outFileNamePrefix ${sample_id}_
    """
}
