process FASTQC {
    tag "$sample_id"
    container 'biocontainers/fastqc:v0.11.9_cv8'
    publishDir "${params.outdir}/qc/fastqc", mode: 'copy'

    input:
        tuple val(sample_id), path(reads)

    output:
        path("*_fastqc.{zip,html}"), emit: reports

    script:
    """
    fastqc --threads ${task.cpus} ${reads}
    """
}
