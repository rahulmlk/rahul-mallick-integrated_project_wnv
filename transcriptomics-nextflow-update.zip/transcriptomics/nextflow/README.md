# WNV Host Transcriptomics — Nextflow Pipeline

A Nextflow DSL2 pipeline for the RNA-seq workflow used in my thesis to
study the host transcriptional response to West Nile Virus infection
(and interferon-pathway agonist stimulation) in human samples.

Dataset: GEO **GSE136342** / BioProject **PRJNA562253** — raw FASTQ
retrieved via an ENA-generated download script. Design: 5 donors x 2
timepoints (12h, 24h) x 5 conditions (Mock, WNV, IFNb, MDA5, RIG-I).

## Pipeline stages

```
raw FASTQ
  │
  ├─ FastQC ─┬─ MultiQC (aggregate QC report)
  │          │  (adapter trimming step available but skipped in the
  │          │   thesis run — adapter content was within acceptable
  │          │   thresholds; see main.nf comments for the Trimmomatic/
  │          │   Cutadapt alternative if your data needs it)
  │
  ├─ STAR alignment (GRCh38, splice-aware)
  │
  ├─ featureCounts (gene-level quantification)
  │
  └─ DESeq2 (design = ~ donor + treatment + timepoint, Mock as
     reference level)
       │
       ├─ Pairwise contrasts: WNV, IFNb, MDA5, RIG-I — each vs Mock,
       │  apeglm log2FC shrinkage, padj < 0.05 & |log2FC| > 1
       ├─ PCA plot (vst-transformed counts)
       ├─ Heatmap of top 50 DEGs across all contrasts
       ├─ GSVA interferon-stimulated-gene (ISG) pathway scoring —
       │  compares induction magnitude across conditions (e.g. IFNb
       │  vs. WNV, to characterize partial interferon suppression)
       └─ GO (BP) / KEGG enrichment per contrast (clusterProfiler),
          after Ensembl → Entrez ID mapping
```

## Files

```
main.nf                          workflow definition, two entry points
nextflow.config                  containers, resources, test profile
modules/
  fastqc.nf, multiqc.nf          QC
  star_align.nf                  GRCh38 alignment
  featurecounts.nf               gene-level quantification
  deseq2.nf                      wraps bin/deseq2_analysis.R
bin/
  deseq2_analysis.R              DESeq2 + apeglm + PCA + heatmap +
                                  GSVA + GO/KEGG enrichment
test_data/
  counts_full_design.csv         synthetic 20-sample, 25-gene count
                                  matrix matching the real donor x
                                  timepoint x condition design
  metadata_full_design.csv       matching sample metadata
```

## Running it

**Downstream-only (testable without a genome/FASTQ/Docker daemon issues
aside)** — runs QC-through-enrichment logic against the included
synthetic dataset:

```bash
nextflow run main.nf -profile test
```

**Full pipeline**, from real FASTQ files (needs a STAR index, GTF
annotation, and Docker or Singularity):

```bash
nextflow run main.nf \
    --reads 'data/*_R{1,2}.fastq.gz' \
    --star_index /path/to/GRCh38_STAR_index \
    --gtf /path/to/gencode.v42.annotation.gtf \
    --outdir results
```

**Downstream-only with your own count matrix** (e.g. counts from a
different aligner/quantifier, or a real experiment):

```bash
nextflow run main.nf --skip_alignment \
    --counts my_counts.csv --metadata my_metadata.csv \
    --isg_genes STAT1,IRF7,IFIH1,MX1,OAS1,ISG15 \
    --outdir results
```

`metadata.csv` must have `sample,treatment,donor,timepoint` columns
with `Mock` present as a treatment level (matching the thesis design).

## What's genuinely offline-testable vs. what needs real infrastructure

| Stage | Needs |
|---|---|
| FastQC / MultiQC / STAR / featureCounts | Real FASTQ + reference genome + Docker/Singularity + compute (GB-scale memory for STAR) |
| DESeq2 / apeglm / PCA / heatmap / GSVA | Only a count matrix + metadata — this is what `-profile test` exercises |
| GO/KEGG enrichment | Real Ensembl gene IDs (the synthetic test data's `GENE###` IDs aren't real, so `-profile test` sets `--skip_enrichment` automatically) |

This pipeline was written and reviewed for correctness against the
DESeq2/GSVA/clusterProfiler APIs, but **not executed end-to-end** in
the sandbox that generated it — it has no Docker daemon or internet
access to pull the tool containers. Run `-profile test` on your own
machine (with Nextflow + Docker installed) as a first sanity check
before pointing it at real data.

## Requirements

- [Nextflow](https://www.nextflow.io/) ≥ 23.04
- Docker or Singularity (containers are pinned in `nextflow.config`)
- For the full pipeline: a STAR genome index and GTF annotation for
  GRCh38 (e.g. GENCODE v42, matching the thesis pipeline)
